using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]

public class PlayerController : MonoBehaviour
{
    private Rigidbody playerRb;

    public float jumpForce;
    public float gravityMultiplier;
    public bool isOnGround = true;

    private bool _gameOver = false;
    public bool GameOver
    {

        // => es una funcion landa y puede usarse en lugar de {}

        get => _gameOver; //metodo getter
        //set => _gameOver = value; //metodo setter

        //otra forma para evitar que se cambie de forma externa
        //(pero no vale pa na, simplemente no se impleneta el set y ale)

        set
        {
            if (_gameOver == true)
            {
                _gameOver = true;
            }
            _gameOver = value;
        }
    }
    
    // Start is called before the first frame update
    void Start()

    {
        playerRb = GetComponent<Rigidbody>();
        Physics.gravity *= gravityMultiplier;

    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.Space) && isOnGround)
        {
            playerRb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse); //F = m*a
            isOnGround = false;
        }
    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Ground"))
        {
            isOnGround = true;
        }else if (other.gameObject.CompareTag("Obstacle"))
        {
            Debug.Log("GAME OVER");
            _gameOver = true;
        }
       
    }
}
